package com.example.praktikum2


import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val editTextCost = findViewById<EditText>(R.id.editTextCost)
        val radioGroup = findViewById<RadioGroup>(R.id.radioGroup)
        val switchRoundUp = findViewById<Switch>(R.id.switchRoundUp)
        val buttonCalculate = findViewById<Button>(R.id.buttonCalculate)
        val textViewTipAmount = findViewById<TextView>(R.id.textViewTipAmount)

        buttonCalculate.setOnClickListener {
            calculateTip(editTextCost, radioGroup, switchRoundUp, textViewTipAmount)
        }
    }

    private fun calculateTip(
        editTextCost: EditText,
        radioGroup: RadioGroup,
        switchRoundUp: Switch,
        textViewTipAmount: TextView
    ) {
        val costString = editTextCost.text.toString()
        val cost = costString.toDoubleOrNull()

        if (cost == null) {
            textViewTipAmount.text = getString(R.string.error_message)
            return
        }

        val tipPercentage = when (radioGroup.checkedRadioButtonId) {
            R.id.radioButtonAmazing -> 0.20
            R.id.radioButtonGood -> 0.18
            R.id.radioButtonOkay -> 0.15
            else -> 0.0
        }

        var tip = cost * tipPercentage

        if (switchRoundUp.isChecked) {
            tip = kotlin.math.ceil(tip)
        }

        textViewTipAmount.text = getString(R.string.tip_amount, tip)
    }
}